class connection:
    def __init__(self):
        